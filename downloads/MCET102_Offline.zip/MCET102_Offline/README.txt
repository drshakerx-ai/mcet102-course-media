MCET 102 Mechanical Measurements — offline edition
Yanbu Industrial College · Mechanical Engineering Department
(c) 2026 Dr. Shaker A. Reda Khojah. All rights reserved.

HOW TO START
1. Unzip this folder (right-click > Extract All). Do not run it from inside the zip.
2. Double-click  "Start MCET102.html". It opens in your web browser (Chrome or Edge recommended).
3. Sign in with your Student ID, then choose an experiment.

No internet is needed. Your progress and lab work are saved on this computer under your Student ID.
On a shared computer press "Sign out" (and in each lab "Clear my work from this computer") when you finish.

طريقة التشغيل: فك الضغط عن المجلد، ثم اضغط مرتين على الملف "Start MCET102.html" فيفتح في المتصفح ويعمل بدون إنترنت.
